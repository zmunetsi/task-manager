<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><h2><?php echo e($project->name); ?></h2>

                    <li class="d-flex justify-content-between align-items-center">
                        
                           <a href = "/tasks/create?project_id=<?php echo e($project->id); ?>"><span class="badge badge-primary badge-pill">Add new task</span></a>
                          </li>
                        

                </div>

                <div class="card-body">
                       <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(count($project->tasks) > 0): ?>

                    <div class = "ajax-success"></div>


                    <ul id = "sortable-items" class="list-group">

                  <button type="button" class="list-group-item list-group-item-action active">
                    Tasks
                  </button>

                  <?php $__currentLoopData = $project->tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                      <li data-id="<?php echo e($task->id); ?>" class="draggable list-group-item d-flex justify-content-between align-items-center">
                        <?php echo e($task->name); ?>

                        <a href = "<?php echo e(route('tasks.edit',$task)); ?>" class="badge badge-primary badge-pill">Edit</a>
                        
                         <form method="POST" action="/tasks/<?php echo e($task->id); ?>">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?>


                        
                            <button style = "border:none;" type="submit" class="badge badge-danger badge-pill">
                                delete
                            </button>
                    </form>
                      </li>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                    </ul>

                   <?php endif; ?>

                </div>
            </div>


             
    
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\dev\Desktop\task_manager\resources\views/project/show.blade.php ENDPATH**/ ?>