<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                       <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <a href="<?php echo e(route('projects.create')); ?>">Create new project</a>
                </div>
            </div>

            <?php $__currentLoopData = $all_projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

             

                <div class="card gedf-card">

                    <div class="accordion" id="accordionExample">
                  <div class="card">
                    <div class="card-header" id="headingOne">
                      <h2 class="mb-0">
                        
                          <li class="d-flex justify-content-between align-items-center">
                            <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapse-<?php echo e($project->id); ?>" aria-expanded="true" aria-controls="collapseOne">
                           <h2><?php echo e($project->name); ?></h2>
                           </button>
                           <a href = "<?php echo e(route('projects.show',$project)); ?>"><span class="badge badge-primary badge-pill">View Project</span></a>
                          </li>
                        
                      </h2>
                    </div>

                        <div id="collapse-<?php echo e($project->id); ?>" class="collapse hide" aria-labelledby="headingOne" data-parent="#accordionExample">
                          <div class="card-body">
                          <?php echo e($project->description); ?>

                          </div>
                        </div>
                      </div>
                      

                    </div>
                    
                </div>
         



                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


               

             

                <div class="card gedf-card">
                    
                </div>
         
    
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\dev\Desktop\task_manager\resources\views/home.blade.php ENDPATH**/ ?>